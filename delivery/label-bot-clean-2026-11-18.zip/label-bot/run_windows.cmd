@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Run setup_windows.cmd first.
 exit /b 1
)
if not exist ".env" (
 echo Create .env from .env.example and fill in your credentials.
 exit /b 1
)
".venv\Scripts\python.exe" main.py
