# Сервис Linux

Это шаблон для НОВОГО сервера покупателя. Он не содержит подключения к серверу продавца.
Используйте каталог /opt/label-bot или согласованно измените пути в unit-файле.
Создайте системного пользователя labelbot; передайте ему папку проекта, включая
право записи в output/. Выполните setup_linux.sh и настройте .env.

После этого администратор может установить сервис:

```bash
sudo cp deploy/label-bot.service /etc/systemd/system/label-bot.service
sudo systemctl daemon-reload
sudo systemctl enable --now label-bot
sudo systemctl status label-bot --no-pager
```

Проверка журналов: `sudo journalctl -u label-bot -n 100 --no-pager`.
Остановка: `sudo systemctl stop label-bot`.
main.py сам читает локальный .env. Токен в unit-файле не хранится.
