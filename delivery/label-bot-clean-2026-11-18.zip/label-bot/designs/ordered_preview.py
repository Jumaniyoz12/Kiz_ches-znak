"""Standalone optional label design, using only the buyer's supplied JSON data."""
import argparse
import json
from datetime import date
from pathlib import Path

from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.barcode import createBarcodeDrawing
from reportlab.graphics import renderPDF


def create_preview(product, destination):
    root = Path(__file__).resolve().parent.parent
    for name, file in [("PreviewArial", "arial.ttf"), ("PreviewBold", "arialbd.ttf")]:
        pdfmetrics.registerFont(TTFont(name, str(root / "fonts" / file)))
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    width, height = 58 * mm, 40 * mm
    pdf = canvas.Canvas(str(destination), pagesize=(width, height))

    def text(x, y, value, size=5.2, bold=False, max_width=54, centered=False):
        font = "PreviewBold" if bold else "PreviewArial"
        value = str(value or "")
        while size > 3.8 and pdfmetrics.stringWidth(value, font, size) > max_width * mm:
            size = max(3.8, size - 0.1)
        if pdfmetrics.stringWidth(value, font, size) > max_width * mm:
            raise ValueError("Text does not fit: " + value)
        pdf.setFont(font, size)
        method = pdf.drawCentredString if centered else pdf.drawString
        method(x * mm, height - y * mm, value)

    def row(y, label, value, size=5.2, bold=False, max_width=38):
        text(2, y, label, 4.8, max_width=15)
        text(18, y, value, size, bold, max_width=max_width)

    text(29, 3.7, product["brand"], 8.7, True, centered=True)
    barcode = createBarcodeDrawing("Code128", value=product["barcode"],
                                   barHeight=9 * mm, humanReadable=False)
    pdf.saveState()
    pdf.translate(2 * mm, height - 14.1 * mm)
    pdf.scale(54 * mm / barcode.width, 1)
    renderPDF.draw(barcode, pdf, 0, 0)
    pdf.restoreState()
    text(29, 16.7, product["barcode"], 6.5, centered=True)
    text(29, 19.6, product["subject"], 6.8, True, centered=True)
    pdf.setStrokeGray(0.65)
    pdf.setLineWidth(0.25)
    pdf.line(2 * mm, height - 20.4 * mm, 56 * mm, height - 20.4 * mm)
    row(23, "Артикул:", product["seller_article"], 6.1, True, 24)
    row(25.6, "Артикул WB:", product["wb_article"], 6.2, True, 24)
    row(28.2, "Цвет:", product["color"], 5.4, max_width=24)
    pdf.setStrokeGray(0)
    pdf.setLineWidth(0.45)
    pdf.roundRect(43 * mm, height - 29.7 * mm, 13 * mm, 8.8 * mm, 1 * mm)
    parts = product["size"].rsplit(maxsplit=1)
    if len(parts) == 2 and any(c.isdigit() for c in parts[0]) and parts[1].isalpha():
        size_value, unit = parts[0], parts[1].upper()
    else:
        size_value, unit = product["size"].upper(), ""
    text(49.5, 22.2, "РАЗМЕР", 3.8, centered=True, max_width=11)
    text(49.5, 26.7, size_value, 11.5, True, centered=True, max_width=11)
    text(49.5, 28.9, unit, 4.2, True, centered=True, max_width=11)
    row(30.9, "Состав:", product["composition"], 5)
    row(33, "Производство:", product["production"], 5.1, True)
    row(35.1, "Поставщик:", product["supplier"], 5.1)
    row(37.2, "Адрес:", product["supplier_address"], 4.8)
    pdf.setStrokeGray(0.65)
    pdf.setLineWidth(0.25)
    pdf.line(2 * mm, height - 37.8 * mm, 56 * mm, height - 37.8 * mm)
    # The demo defaults to today's date; the buyer may supply an explicit date.
    stamp = product.get("production_date") or date.today().strftime("%d.%m.%Y")
    text(2, 39.2, "Дата производства: " + stamp, 4, max_width=44)
    text(49, 39.2, "EAC", 5.4, True, max_width=7)
    pdf.showPage()
    pdf.save()
    return destination


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate the optional ordered label design")
    parser.add_argument("--data", default="samples/preview_product.json")
    parser.add_argument("--out", default="output/demo-ordered.pdf")
    arguments = parser.parse_args()
    with open(arguments.data, encoding="utf-8-sig") as stream:
        print(create_preview(json.load(stream), arguments.out))
