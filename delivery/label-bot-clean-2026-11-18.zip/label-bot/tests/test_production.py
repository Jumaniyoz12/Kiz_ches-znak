import unittest
from dataclasses import asdict

from data import merge_products, _row_to_product
from models import Product


class ProductionTests(unittest.TestCase):
    def test_production_is_read_for_each_product(self):
        products = merge_products([
            {"Баркод": "2200000000001", "Производство:": " Кыргызстан "},
            {"Баркод": "2047882863154", "Производство:": "Другая страна"},
            {"Баркод": "2047882863161"},
        ], [])
        self.assertEqual([p.production for p in products], ["Кыргызстан", "Другая страна", ""])

    def test_production_survives_cache_round_trip(self):
        product = _row_to_product({"Баркод": "2200000000001", "Производство:": "Кыргызстан"})
        self.assertEqual(Product(**asdict(product)).production, "Кыргызстан")

    def test_old_cache_without_production_still_loads(self):
        old_row = asdict(_row_to_product({"Баркод": "2200000000001"}))
        old_row.pop("production", None)
        self.assertEqual(Product(**old_row).production, "")


if __name__ == "__main__":
    unittest.main()
