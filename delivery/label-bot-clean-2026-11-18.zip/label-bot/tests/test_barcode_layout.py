from dataclasses import replace
from datetime import date
from pathlib import Path
import tempfile
import unittest

import pymupdf
import zxingcpp

from models import LabelItem, MarkCode, Product
from pdf_generator import create_labels_pdf


def product():
    return Product(brand="DEMO BRAND", subject="Костюмы спортивные",
                   seller_article="DEMO-SPORT-01", wb_article="100000001",
                   size="10 лет", color="", supplier="Демо поставщик",
                   barcode="2200000000001", production="Кыргызстан")


class BarcodeLayoutTests(unittest.TestCase):
    def render(self, products):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        items = [LabelItem(p, MarkCode("", p.gtin, True, ""), i)
                 for i, p in enumerate(products, 1)]
        path = Path(self.directory.name) / "labels.pdf"
        create_labels_pdf(items, path, include_mark_code=False,
                          creation_date=date(2026, 11, 13))
        document = pymupdf.open(path)
        self.addCleanup(document.close)
        return document

    def test_country_and_large_size_box_match_approved_design(self):
        page = self.render([product()])[0]
        text = page.get_text()
        for value in ["Производство:", "Кыргызстан", "РАЗМЕР", "10", "ЛЕТ",
                      "DEMO-SPORT-01", "100000001", "Демо поставщик", "13.11.2026"]:
            self.assertIn(value, text)
        self.assertNotIn("Цвет:", text)
        self.assertGreater(page.search_for("РАЗМЕР")[0].x0, 42 * 72 / 25.4)
        spans = [s for b in page.get_text("dict")["blocks"] if "lines" in b
                 for line in b["lines"] for s in line["spans"]]
        self.assertTrue(any(s["text"] == "10" and s["size"] >= 13 for s in spans))

    def test_barcode_decodes_at_thermal_printer_resolution(self):
        products = [replace(product(), size=f"{age} лет") for age in range(8, 15)]
        document = self.render(products)
        for page in document:
            for dpi in [203, 300]:
                image = page.get_pixmap(dpi=dpi, alpha=False).pil_image()
                decoded = zxingcpp.read_barcodes(image, formats=zxingcpp.BarcodeFormat.Code128)
                self.assertIn(product().barcode, [r.text for r in decoded])

    def test_approved_larger_barcode_is_nine_mm_high(self):
        page = self.render([product()])[0]
        points_per_mm = 72 / 25.4
        bars = [drawing["rect"] for drawing in page.get_drawings()
                if drawing.get("fill") == (0, 0, 0)
                and drawing["rect"].y0 >= 5.9 * points_per_mm
                and drawing["rect"].y1 <= 15.1 * points_per_mm]
        self.assertTrue(bars)
        self.assertAlmostEqual(max(r.height for r in bars), 9 * points_per_mm, places=3)
        spans = [s for b in page.get_text("dict")["blocks"] if "lines" in b
                 for line in b["lines"] for s in line["spans"]]
        number = next(s for s in spans if s["text"] == product().barcode)
        self.assertAlmostEqual(number["size"], 6.5, places=2)

    def test_long_fields_and_size_formats_stay_inside_label(self):
        sizes = ["116", "110-116", "8-9 лет", "ONE SIZE", "XS", "104-110 см"]
        products = [replace(product(), size=s, seller_article="TK-LONG-ARTICLE-123456789",
                            subject="Костюм спортивный детский для мальчиков",
                            production="Кыргызская Республика") for s in sizes]
        for page, p in zip(self.render(products), products):
            text = page.get_text()
            self.assertIn(p.seller_article, text)
            self.assertIn(p.production, text)
            for token in p.size.split():
                self.assertIn(token.upper(), text)
            spans = [s for b in page.get_text("dict")["blocks"] if "lines" in b
                     for line in b["lines"] for s in line["spans"]]
            for span in spans:
                x0, y0, x1, y1 = span["bbox"]
                self.assertGreaterEqual(x0, 0)
                self.assertGreaterEqual(y0, 0)
                self.assertLessEqual(x1, page.rect.width)
                self.assertLessEqual(y1, page.rect.height)

    def test_missing_country_is_not_invented(self):
        text = self.render([replace(product(), production="")])[0].get_text()
        self.assertNotIn("Производство:", text)
        self.assertNotIn("Кыргызстан", text)


if __name__ == "__main__":
    unittest.main()
